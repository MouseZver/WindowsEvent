Add-Type -as System.Windows.Forms;
[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point( {{x}}, {{y}} );